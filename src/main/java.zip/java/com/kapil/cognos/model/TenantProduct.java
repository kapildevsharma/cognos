package com.kapil.cognos.model;

public class TenantProduct {

}
